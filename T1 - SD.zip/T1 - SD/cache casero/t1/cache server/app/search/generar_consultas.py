import numpy as np
import matplotlib.pyplot as plt
import math

def generateUniformFrequencies(constant_value, numrange):
  x = np.array(list(range(numrange)))
  y = np.full(numrange, constant_value)

  return {'x_axis': x, 'y_axis': y}
  

def generateGaussianFrequencies(mu, sigma, numrange):
 
 def gaussian(mu, sigma, x):
  f = 1/(sigma * np.sqrt(2 * np.pi)) * np.exp( - (x - mu)**2 / (2 * sigma**2))
  return f

 x = np.array(list(range(numrange)))
 y = np.array([])

 for i in range(0, numrange):
    res = math.trunc(gaussian(mu, sigma, i) * 1e4)
    y = np.append(y, res)

 for i in range(50 - 30, 50 + 30):
   y[i] = y[i] + 1 

 return {'x_axis': x, 'y_axis': y}


def graphDistr(axis_arr, title, color):
  plt.plot(axis_arr['x_axis'], axis_arr['y_axis'], c=color)
  if color != 'blue': 
    plt.title(title)
  

# x values between [0, 100]. u = 50, sigma = 10
u = 50
sigma = 15
axis_normal = generateGaussianFrequencies(u, sigma, 100)
total_freq = np.sum(axis_normal['y_axis'])
axis_uniform = generateUniformFrequencies(100, 100)

#print(total_freq)

#graphDistr(axis_normal, f'Distribución normal, con u = {u}, sigma = {sigma} y Distribución uniforme, con f = 100', 'red')
#graphDistr(axis_uniform, 'Distribución uniforme, con f = 100', 'blue')
#plt.xlabel('Query key number')
#plt.ylabel('Frequency')
#plt.show()



