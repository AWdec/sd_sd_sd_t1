from pymemcache.client import base
from find_car_by_id import find_car_by_id
import numpy as np
import time

class cacheClient:
    
    host = 'localhost'
    port = 11211
    client = base.Client((host, port))
    json_path = './cars.json'

    def simulateTime(self, u, sigma, sim):
        sim_time = np.random.normal(u, sigma)
        if sim: # solo aplicamos el tiempo realmente si sim = True
           time.sleep(sim_time)

        return sim_time

    def getFromJSON(self, key, sim):
        t = self.simulateTime(2, 0.5, sim)
        return {'res': find_car_by_id(int(key)), 'delay': t }

    def set(self, key, val):
        res = self.client.set(str(key), str(val))

        return res

    def get(self, key, sim=True): # return val and time

        start_time = time.time()  # Inicio del temporizador
        elapsed_time = -1
        fJSON = False
        
        # Chequeo typeof key == int
        try:
            key = int(key)
        except ValueError:
            print('Solo se permite buscar claves enteras')
            return {'res': None, 'elapsed_time': elapsed_time, 'fromJSON': fJSON}
 
        if key < 0:
           print('Solo keys >= 0')
           return {'res': None, 'elapsed_time': elapsed_time, 'fromJSON': fJSON} 
        
        # Primero, intentamos buscar en memcached
        res = self.client.get(str(key))

        
        if res is None: #  no se encontro la key en cache
          #print(f'No se encontró la key {key} en caché.')
          val_from_JSON = self.getFromJSON(key, sim)            

          if val_from_JSON['res'] is not None:

           res = self.set(key, str(val_from_JSON['res']))

           response = str(val_from_JSON['res'])
           fJSON = True

           elapsed_time = time.time() - start_time

           #print(f'La clave {key} fue encontrada en el JSON con el valor {val_from_JSON["res"]}\nInsertando en memcached...')
           #print(f"Tiempo tardado: {elapsed_time:.5f} segs.")

          else: # no se encontro la key en el JSON
           elapsed_time = time.time() - start_time
           response = None
           #print(f'Tampoco se encontró la key {key} en el archivo {self.json_path[2:]}')

          if not sim: # si sim era falso, elapsed_time no contaría delay por tanto hay que sumarlo...
             elapsed_time += val_from_JSON['delay']

        else:
           elapsed_time = time.time() - start_time
           response = res
    
        
        return {'res': response, 'elapsed_time': elapsed_time, 'fromJSON': fJSON}


clientObj = cacheClient()


if __name__ == '__main__':
    while True:
       key = input('write find key:')
       r = clientObj.get(key, False)
       
       if r['res'] is not None:
        if not r['fromJSON']:
            print(f'La clave {key} fue encontrada en: MEMCACHED, en un tiempo de: {r["elapsed_time"]:.5f}[segs] y con un valor de:\n{r["res"]}\n')
        else:
            print(f'La clave {key} fue encontrada en: JSON, en un tiempo de: {r["elapsed_time"]:.5f}[segs] y con un valor de:\n{r["res"]}\n')
       else:
        print(f'La clave {key} no fue encontrada en caché ni en JSON...')

