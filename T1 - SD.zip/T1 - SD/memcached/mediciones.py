from server import cacheClient
from generar_consultas import axis_normal, axis_uniform

clientObj = cacheClient()

def get_Ntimes(key, times):
    # este es el tiempo que tomó hacer 'times' consultas de la key='key'
    time_acc = 0
    #print(times)
    for i in range(times):
        r = clientObj.get(key, False)
        time_acc += r['elapsed_time']
    
    return time_acc

general_time_acc_n = 0 # normal counter 
general_time_acc_u = 0 # uniform counter

'''
# medicion para distr. normal
for i in range(len(axis_normal['y_axis'])):
    cur_key_time_acc = get_Ntimes(i, int(axis_normal['y_axis'][i]))
    general_time_acc_n += cur_key_time_acc

print(general_time_acc_n)

'''


# medicion para distr. uniforme
for i in range(len(axis_uniform['y_axis'])):
    cur_key_time_acc = get_Ntimes(i, int(axis_uniform['y_axis'][i]))
    general_time_acc_u += cur_key_time_acc

print(general_time_acc_u)
